# Copyright (c) 2015 STMicroelectronics.

This software component is licensed by  ST under Ultimate Liberty license SLA0044, the "License". You may not use this file except in compliance with this license. You may obtain a copy of the license [here](https://www.st.com/SLA0044).
